#include <pch.h>
#include "L_MoveForward.h"

void L_MoveForward::on_enter()
{
	if(IsFirstSetup)
	{
		//agent->set_position(Vec3(0, 0, 50.f));
		
		targetPoint = Vec3(0, 0, 100.f);
		bool hasBehind = false;
		auto& bb = agent->get_blackboard();
		bb.set_value("Runner Corner", targetPoint);
		bb.set_value("Has Behind", hasBehind);
		agent->set_movement_speed(10.f);

		IsFirstSetup = false;
	}
	BehaviorNode::on_leaf_enter();
}


void L_MoveForward::on_update(float dt)
{
	display_leaf_text();
	
	Vec3 pos = agent->get_position();
	
	const auto& bb = agent->get_blackboard();
	targetPoint = bb.get_value<Vec3>("Runner Corner");

	agent->move_toward_point(targetPoint, dt);

	//std::cout << pos.x << ", " << pos.y << ", " << pos.z << "\n";
	
	//std::cout << pos.x << std::endl;
	//Vec3 forward = agent->get_forward_vector();

	if (targetPoint == botR)
	{
		if (abs(pos.z - targetPoint.z) < epsilon)
		{
			on_failure();
		}
	}
	else if (targetPoint == topR)
	{
		if (abs(pos.x - targetPoint.x) < epsilon)
		{
			on_failure();
		}
	}
	else if (targetPoint == topL)
	{
		if (abs(pos.z - targetPoint.z) < epsilon)
		{
			on_failure();
		}
	}	
	else if(targetPoint == botL)
	{
		if (abs(pos.x - targetPoint.x) < epsilon)
		{
			on_failure();
		}
	}
	else
	{
		on_success();
	}
	
}

