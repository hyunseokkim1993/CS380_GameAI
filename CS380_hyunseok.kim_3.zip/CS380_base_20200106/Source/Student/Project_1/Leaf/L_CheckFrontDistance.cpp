#include <pch.h>
#include "Agent/BehaviorAgent.h"
#include "L_CheckFrontDistance.h"

//void L_CheckFrontDistance::on_enter()
//{
//
//
//
//
//	display_leaf_text();
//}

void L_CheckFrontDistance::on_update(float dt)
{
	// get a list of all current agents
	const auto& allAgents = agents->get_all_agents();

	// and our agent's position
	const auto& currPos = agent->get_position();


	//sum += dt;
	//while(sum <= 5.f)
	//{
	//sum -= dt;
	//while(sum > 0)
	//{
		for (const auto& a : allAgents)
		{
			// make sure it's not our agent
			if (a != agent)
			{
				const auto& agentPos = a->get_position();
				const float distance = Vec3::Distance(currPos, agentPos);

				if (distance < 1.f)
				{
					isThereNeighbor = true;
				}
			}
		}
//	}

	//}
	
	if (isThereNeighbor == true)
	{
		//sum = 5.f;
		isThereNeighbor = false;
		on_success();
	}
	else
	{
		//sum = 5.f;
		on_failure();
	}
	display_leaf_text();
	
}

