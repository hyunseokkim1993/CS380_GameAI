#include <pch.h>
#include "L_TurnNinety.h"

void L_TurnNinety::on_enter()
{
	display_leaf_text();
	
	auto& bb = agent->get_blackboard();
	Vec3 goal = bb.get_value<Vec3>("Runner Corner");
	
	if(goal == botR)
	{
		bb.set_value("Runner Corner", topR);
	}
	else if (goal == topR)
	{
		bb.set_value("Runner Corner", topL);
	}
	else if (goal == topL)
	{
		bb.set_value("Runner Corner", botL);
	}
	else if (goal == botL)
	{
		bb.set_value("Runner Corner", botR);
	}

	//on_failure();
	on_success();
}

