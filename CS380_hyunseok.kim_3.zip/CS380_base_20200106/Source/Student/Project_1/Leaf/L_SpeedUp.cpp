#include <pch.h>
#include "L_SpeedUp.h"

void L_SpeedUp::on_enter()
{
	display_leaf_text();
	

	if(agent->get_movement_speed() < 100.f)
	{
		agent->set_movement_speed(agent->get_movement_speed() + 10.f);
	}
	

	
	on_success();
}


