#pragma once
#include "BehaviorNode.h"

class L_CheckFrontDistance : public BaseNode<L_CheckFrontDistance>
{
protected:
	//virtual void on_enter() override;
	virtual void on_update(float dt) override;

private:
	//Vec3 targetPoint;
	bool isThereNeighbor = false;
	float sum = 4.f;
};