#pragma once
#include "BehaviorNode.h"
#include "Misc/NiceTypes.h"

class L_Rotate : public BaseNode<L_Rotate>
{
protected:
	//virtual void on_enter() override;
	virtual void on_update(float dt) override;

private:
	Vec3 Color;
	float scaler = 0.1f;
	int counter = 0;
	float sum = 0;
};