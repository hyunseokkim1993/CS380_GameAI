#pragma once
#include "BehaviorNode.h"
#include "Misc/NiceTypes.h"

class L_Flock : public BaseNode<L_Flock>
{
protected:
	virtual void on_enter() override;
	virtual void on_update(float dt) override;

private:
	Vec3 ForwardVector;
	Vec3 CurrentPosition;
	Vec3 NeighborPosition;

	bool IsInitialSetup = true;
	Vec3 Alignment;
	Vec3 Cohesion;
	Vec3 Seperation;

	float DetectionDist = 5.f;

public:
	Vec3 GetRandVec()
	{
		const float x = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));
		const float y = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));
		const float z = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));
		return Vec3(x, y, z);
	}
	
};