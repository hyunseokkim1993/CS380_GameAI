#include <pch.h>
#include "Agent/BehaviorAgent.h"
#include "L_RotateFast.h"

void L_RotateFast::on_enter()
{
	timer = 5.0f;//RNG::range(1.0f, 2.0f);

	BehaviorNode::on_leaf_enter();
}

void L_RotateFast::on_update(float dt)
{

	agent->set_yaw(agent->get_yaw() + scaler);
	//	counter++;
	//	sum += dt;
		//sum += scaler;

	//}
	//shouldExit = true;
	//if (sum >= 200.f)

	//sum += dt;
	//if (sum >= 5.f)
	//{
	//	sum = 0;
		//on_success();
	//}

		timer -= dt;

		if (timer < 0.0f)
		{
			on_success();
		}

	display_leaf_text();
}

