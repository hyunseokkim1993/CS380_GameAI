#include <pch.h>
#include "L_SetUpRandomStartPos.h"
#include "Agent/BehaviorAgent.h"

void L_SetUpRandomStartPos::on_enter()
{
	//auto& bb = agent->get_blackboard();
	//bb.set_value("IsInitialization", targetPoint);
	
	if(isFirst)
	{
		
		const float x = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));
		const float y = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));
		const float rotation = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));


		agent->set_position(Vec3(x, 0.f, y));
		agent->set_yaw(rotation);

		isFirst = false;
	}

	BehaviorNode::on_leaf_enter();
}

void L_SetUpRandomStartPos::on_update(float dt)
{

	display_leaf_text();
	on_success();
}

