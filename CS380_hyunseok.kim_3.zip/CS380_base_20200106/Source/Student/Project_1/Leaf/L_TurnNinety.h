#pragma once
#include "BehaviorNode.h"

class L_TurnNinety : public BaseNode<L_TurnNinety>
{
protected:
	virtual void on_enter() override;
	//virtual void on_update(float dt) override;

private:
	Vec3 botR	= Vec3(0, 0, 100.f);
	Vec3 topR	= Vec3(100.f, 0, 100.f);
	Vec3 topL	= Vec3(100.f, 0, 0);
	Vec3 botL	= Vec3(0, 0, 0);
	
};
