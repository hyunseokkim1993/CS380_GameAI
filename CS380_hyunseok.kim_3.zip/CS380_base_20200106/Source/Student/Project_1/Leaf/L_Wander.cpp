#include <pch.h>
#include "L_Wander.h"
#include "Agent/BehaviorAgent.h"

void L_Wander::on_enter()
{
	InitialPosition = agent->get_position();
	CircleCenter = agent->get_forward_vector();
	CircleCenter.Normalize();
	CircleCenter *= CircleRadius;

	agent->set_color(Vec3(0, 0, 1.f));
	
	Vec3 Displacement = Vec3(0, 0, 1.f);
	Displacement *= CircleRadius;

	float dot = CircleCenter.Dot(Displacement);
	float angle = 2 * 3.14f * (dot / 360.f);

	float random = 1 + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (5 - 1)));


	
	angle += (random * 2);// - (2 * .5f);
	angle = abs(angle);

	float len = Displacement.Length();
	Displacement.x = cos(angle) * len;
	Displacement.y = 0;
	Displacement.z = cos(angle) * len;

	
	destination = CircleCenter +Displacement + InitialPosition;



	
	BehaviorNode::on_leaf_enter();
}


void L_Wander::on_update(float dt)
{
	const auto result = agent->move_toward_point(destination , dt);

	if (result == true)
	{
		on_success();
	}

	if (agent->get_position().x < 0 || agent->get_position().x > 100 || agent->get_position().z < 0 || agent->get_position().z > 100)
	{

		const float x = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));
		const float y = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));
		const float rotation = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));

		agent->set_position(Vec3(x, 0.f, y));
		agent->set_yaw(rotation);
		on_failure();
	}
	

	
	
	//wanderAngle += (Math.random() * ANGLE_CHANGE) - (ANGLE_CHANGE * .5);
	display_leaf_text();

	
	
	
}
