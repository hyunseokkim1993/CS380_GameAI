#pragma once
#include "BehaviorNode.h"

class L_CheckBackDistance : public BaseNode<L_CheckBackDistance>
{
protected:
	virtual void on_enter() override;
	virtual void on_update(float dt) override;

private:
	//Vec3 targetPoint;
};