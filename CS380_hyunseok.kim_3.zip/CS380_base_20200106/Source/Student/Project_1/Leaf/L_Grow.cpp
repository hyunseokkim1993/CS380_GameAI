#include <pch.h>
#include "Agent/BehaviorAgent.h"
#include "L_Grow.h"

void L_Grow::on_enter()
{
	const auto leftMouseState = InputHandler::get_current_state(MouseButtons::LEFT);


	if (leftMouseState == InputHandler::InputState::PRESSED)
	{
		if(counter <10)
		{
			agent->set_scaling(agent->get_scaling()*scaler);
			counter++;
		}

	}


	on_success();
	display_leaf_text();
}

