#include <pch.h>
#include "L_CheckBackDistance.h"
#include "Agent/BehaviorAgent.h"

void L_CheckBackDistance::on_enter()
{
	bool targetFound = false;

	const auto& allAgents = agents->get_all_agents();
	const auto& currPos = agent->get_position();

	Vec3 Detection = agent->get_forward_vector();
	Detection *= -50.f;
	Detection += currPos;

	for (const auto& a : allAgents)
	{
		// make sure it's not our agent
		if (a != agent)
		{
			const auto& agentPos = a->get_position();
//			const float distance = Vec3::Distance(Detection, agentPos);
			const Vec3 distance = (Detection - agentPos);
			float d = abs(distance.Length());

			if (d < 0.1f)
			{
				targetFound = true;
			}
		}
	}

	if (targetFound == true)
	{
		auto& bb = agent->get_blackboard();
		bb.set_value("Has Behind", true);
		on_failure();
		//on_success();
		//BehaviorNode::on_leaf_enter();
	}
	else // couldn't find a viable agent
	{
		on_success();
		//on_failure();
	}
	BehaviorNode::on_leaf_enter();
	display_leaf_text();
}

void L_CheckBackDistance::on_update(float dt)
{

	//on_success();

	//on_failure();
	display_leaf_text();
}

