#include <pch.h>
#include "Agent/BehaviorAgent.h"
#include "L_Rotate.h"

//void L_Rotate::on_enter()
//{
//
//
//
//	
//	on_leaf_enter();
//
//
//}

void L_Rotate::on_update(float dt)
{
	//std::cout << dt << std::endl;

	//bool shouldExit = false;
	//while (sum <= 200.f)
	//{
		agent->set_yaw(agent->get_yaw() + scaler);
	//	counter++;
	//	sum += dt;
		//sum += scaler;
		
	//}
	//shouldExit = true;
	//if (sum >= 200.f)

	//	sum += dt;
	//if(sum >= 5.f)
	//{
		sum = 0;
		on_success();
	//}
	
	display_leaf_text();
}

