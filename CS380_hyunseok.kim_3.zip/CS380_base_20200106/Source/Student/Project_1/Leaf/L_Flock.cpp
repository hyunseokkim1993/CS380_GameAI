#include <pch.h>
#include "L_Flock.h"
#include "Agent/BehaviorAgent.h"
#include <iostream>

void L_Flock::on_enter()
{
	if(IsInitialSetup)
	{
		const float x = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));
		const float y = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));
		const float rotation = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));
		agent->set_scaling(1.f);
		//agent->set_position(Vec3(x, 0.f, y));
		agent->set_yaw(rotation);
		agent->set_color(Vec3(1, 0, 0));
		
		IsInitialSetup = false;
	}
	ForwardVector = agent->get_forward_vector();
	CurrentPosition = agent->get_position();



	BehaviorNode::on_leaf_enter();
}

void L_Flock::on_update(float dt)
{
	//===============================================================================================//
	const auto& allAgents = agents->get_all_agents();
	Alignment = Vec3(0.f);
	Cohesion = Vec3(0.f);
	Seperation = Vec3(0.f);

	float neighborCount = 0;
	bool neighborFound = false;

	for (const auto& a : allAgents)
	{
		// make sure it's not our agent
		if (a->get_color() == Vec3(1,0,0) && a != agent)
		{
			const auto& agentPos = a->get_position();
			const float distance = Vec3::Distance(agent->get_position(), agentPos);

			if (distance < DetectionDist)
			{
				Cohesion += agentPos;
				Alignment += a->get_forward_vector();
				Seperation += agentPos - agent->get_position();
				
				neighborCount++;
				neighborFound = true;
			}
		}
	}

	if (neighborFound)
	{
		//agent->set_color(Vec3(255.f, 0, 0));
		Cohesion /= neighborCount;
		Cohesion = Cohesion - agent->get_position();
		//Cohesion.Normalize();
		
		Alignment /= neighborCount;
		Alignment.Normalize();
		
		Seperation *= -1.f;
		//Seperation.Normalize();

		Vec3 Destination = Cohesion + Alignment + Seperation;
		Destination.Normalize();
		agent->move_toward_point(Destination + agent->get_position(), dt);
	}
	else
	{
		//agent->set_color(Vec3(0.f, 255.f, 0));
		ForwardVector.Normalize();
		agent->move_toward_point(agent->get_position() + ForwardVector, dt);
	}
	if(agent->get_position().x < 0 || agent->get_position().x > 100 || agent->get_position().z < 0 || agent->get_position().z > 100)
	{		
		
		const float x = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));
		const float y = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));
		const float rotation = 1.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (99.f - 1.0f)));

		agent->set_position(Vec3(x, 0.f, y));
		agent->set_yaw(rotation);		
	}

	
	on_success();
	display_leaf_text();
}

