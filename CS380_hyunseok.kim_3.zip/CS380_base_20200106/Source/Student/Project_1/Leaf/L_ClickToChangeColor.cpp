#include <pch.h>
#include "L_ClickToChangeColor.h"
#include "Agent/BehaviorAgent.h"

void L_ClickToChangeColor::on_enter()
{
	const auto leftMouseState = InputHandler::get_current_state(MouseButtons::LEFT);

	
	if (leftMouseState == InputHandler::InputState::PRESSED)
	{
		float r = 0.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (1.f - 0.0f)));
		float g = 0.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (1.f - 0.0f)));
		float b = 0.0f + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (1.f - 0.0f)));
		agent->set_color(Vec3(r,g,b));
		
	}
	

	on_success();
	display_leaf_text();
}

