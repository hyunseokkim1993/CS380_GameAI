#pragma once
#include "BehaviorNode.h"

class L_Wander : public BaseNode<L_Wander>
{
protected:
	virtual void on_enter() override;
	virtual void on_update(float dt) override;

private:
	Vec3 CircleCenter;
	//Vec3 Displacement = Vec3(-1.f,0,0);
	Vec3 InitialPosition;
	Vec3 destination;
	
	const float CircleDistance = 20.f;
	const float CircleRadius = 5.f;
	
};