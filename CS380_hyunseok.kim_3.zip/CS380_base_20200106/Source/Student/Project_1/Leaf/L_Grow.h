#pragma once
#include "BehaviorNode.h"
#include "Misc/NiceTypes.h"

class L_Grow : public BaseNode<L_Grow>
{
protected:
	virtual void on_enter() override;
	//virtual void on_update(float dt) override;

private:
	Vec3 Color;
	float scaler=1.05f;
	int counter = 0;
};