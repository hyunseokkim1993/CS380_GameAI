#pragma once
#include "BehaviorNode.h"
#include "Misc/NiceTypes.h"

class L_RotateFast : public BaseNode<L_RotateFast>
{
protected:
	virtual void on_enter() override;
	virtual void on_update(float dt) override;

private:
	Vec3 Color;
	float scaler = 0.5f;
	int counter = 0;
	float sum = 0;

	float timer = 5.0f;
};