#include <pch.h>
#include "Projects/ProjectOne.h"
#include "Agent/CameraAgent.h"

void ProjectOne::setup()
{
    // Create your inital agents
	 agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);
	agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Test);

	//agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Wander);
	//agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Wander);
	//agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Wander);
	//agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Wander);
	//
	//agents->create_behavior_agent("Runner", BehaviorTreeTypes::Runner);
	//agents->create_behavior_agent("Runner", BehaviorTreeTypes::Runner);
	//agents->create_behavior_agent("Runner", BehaviorTreeTypes::Runner);
	//agents->create_behavior_agent("Runner", BehaviorTreeTypes::Runner);
	//agents->create_behavior_agent("Runner", BehaviorTreeTypes::Runner);
	//
	//agents->create_behavior_agent("Grower", BehaviorTreeTypes::Grower);
	//
	//agents->create_behavior_agent("Changer", BehaviorTreeTypes::Changer);
	//
	//agents->create_behavior_agent("Spinner", BehaviorTreeTypes::Spinner);

    // you can technically load any map you want, even create your own map file,
    // but behavior agents won't actually avoid walls or anything special, unless you code that yourself
    // that's the realm of project 2 though
    terrain->goto_map(0);

    // you can also enable the pathing layer and set grid square colors as you see fit
    // works best with map 0, the completely blank map
    terrain->pathLayer.set_enabled(true);
    terrain->pathLayer.set_value(0, 0, Colors::Aqua);

    // camera position can be modified from this default as well
    auto camera = agents->get_camera_agent();
    //camera->set_position(Vec3(-62.0f, 70.0f, terrain->mapSizeInWorld * 0.5f));
    //camera->set_pitch(0.610865); // 35 degrees
	camera->set_position(Vec3(40.0f, 150.0f, terrain->mapSizeInWorld * 0.5f));
	camera->set_pitch(1.5f); // 35 degrees
}