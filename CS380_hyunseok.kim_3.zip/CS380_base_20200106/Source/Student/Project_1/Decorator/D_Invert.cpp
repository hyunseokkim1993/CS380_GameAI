#include <pch.h>
#include "D_Invert.h"

void D_Invert::on_update(float dt)
{
	BehaviorNode* child = children.front();

	child->tick(dt);

	if (child->succeeded() == true)
	{
		on_failure();
	}
	else if (child->failed() == true)
	{
		on_success();
	}

}