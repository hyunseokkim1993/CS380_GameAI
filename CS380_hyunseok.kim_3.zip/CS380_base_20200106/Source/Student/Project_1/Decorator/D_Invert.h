#pragma once
#include "BehaviorNode.h"

class D_Invert : public BaseNode<D_Invert>
{
public:

protected:
	virtual void on_update(float dt) override;
};