#include <pch.h>
#include "Terrain/TerrainAnalysis.h"
#include "Terrain/MapMath.h"
#include "Agent/AStarAgent.h"
#include "Terrain/MapLayer.h"
#include "Projects/ProjectThree.h"

#include <iostream>

bool ProjectThree::implemented_fog_of_war() const // extra credit
{
	return false;
}

float EuclideanDistanceToWall(int xs, int ys, int xe, int ye)
{
	return sqrtf(static_cast<float>((xe - xs) * (xe - xs) + (ye - ys) * (ye - ys)));
}

float distance_to_closest_wall(int row, int col)
{
	/*
		Check the euclidean distance from the given cell to every other wall cell,
		with cells outside the map bounds treated as walls, and return the smallest
		distance.  Make use of the is_valid_grid_position and is_wall member
		functions in the global terrain to determine if a cell is within map bounds
		and a wall, respectively.
	*/
	int x = 0;
	int y = 0;

	int maxDistance = terrain->get_map_width();
	for (int i = 1; i < maxDistance; ++i)
	{
		//NW
		x = col - i;
		y = row + i;
		if (terrain->is_valid_grid_position(y, x))
		{
			if (terrain->is_wall(y, x))
				return EuclideanDistanceToWall(col, row, x, y);
		}
		else
		{
			return EuclideanDistanceToWall(col, row, x, y);
		}
		//N
		x = col;
		y = row + i;
		if (terrain->is_valid_grid_position(y, x))
		{
			if (terrain->is_wall(y, x))
				return EuclideanDistanceToWall(col, row, x, y);
		}
		else
		{
			return EuclideanDistanceToWall(col, row, x, y);
		}
		//NE
		x = col + i;
		y = row + i;
		if (terrain->is_valid_grid_position(y, x))
		{
			if (terrain->is_wall(y, x))
				return EuclideanDistanceToWall(col, row, x, y);
		}
		else
		{
			return EuclideanDistanceToWall(col, row, x, y);
		}
		//E
		x = col + i;
		y = row;
		if (terrain->is_valid_grid_position(y, x))
		{
			if (terrain->is_wall(y, x))
				return EuclideanDistanceToWall(col, row, x, y);
		}
		else
		{
			return EuclideanDistanceToWall(col, row, x, y);
		}
		//SE
		x = col + i;
		y = row - i;
		if (terrain->is_valid_grid_position(y, x))
		{
			if (terrain->is_wall(y, x))
				return EuclideanDistanceToWall(col, row, x, y);
		}
		else
		{
			return EuclideanDistanceToWall(col, row, x, y);
		}
		//S
		x = col;
		y = row - i;
		if (terrain->is_valid_grid_position(y, x))
		{
			if (terrain->is_wall(y, x))
				return EuclideanDistanceToWall(col, row, x, y);
		}
		else
		{
			return EuclideanDistanceToWall(col, row, x, y);
		}
		//SW
		x = col - i;
		y = row - i;
		if (terrain->is_valid_grid_position(y, x))
		{
			if (terrain->is_wall(y, x))
				return EuclideanDistanceToWall(col, row, x, y);
		}
		else
		{
			return EuclideanDistanceToWall(col, row, x, y);
		}
		//W
		x = col - i;
		y = row;
		if (terrain->is_valid_grid_position(y, x))
		{
			if (terrain->is_wall(y, x))
				return EuclideanDistanceToWall(col, row, x, y);
		}
		else
		{
			return EuclideanDistanceToWall(col, row, x, y);
		}
	}



	return 1.0f; // REPLACE THIS
}

bool is_clear_path(int row0, int col0, int row1, int col1)
{
	/*
		Two cells (row0, col0) and (row1, col1) are visible to each other if a line
		between their center points doesn't intersect the four boundary lines of every
		wall cell.  You should puff out the four boundary lines by a very tiny amount
		so that a diagonal line passing by the corner will intersect it.  Make use of the
		line_intersect helper function for the intersection test and the is_wall member
		function in the global terrain to determine if a cell is a wall or not.
	*/


	// WRITE YOUR CODE HERE
	Vec2 start((float)row0, (float)col0);
	Vec2 end((float)row1, (float)col1);
	
	int width = terrain->get_map_width();
	int height = terrain->get_map_height();

	for(int y=0; y<height; ++y)
	{
		for(int x =0; x < width; ++x)
		{
			//if (row0 == y && col0 == x)
			//	continue;

			//
			if(terrain->is_wall(y,x))
			{
				//UR-BR
				Vec2 box1(y + .55f, x + .55f);
				Vec2 box2(y - .55f, x + .55f);
				if (line_intersect(start, end, box1, box2))
					return false;
				//BR-BL
				box1 = Vec2(y - .55f, x + .55f);
				box2 = Vec2(y - .55f, x - .55f);
				if (line_intersect(start, end, box1, box2))
					return false;
				//BL-UL
				box1 = Vec2(y - .55f, x - .55f);
				box2 = Vec2(y + .55f, x - .55f);
				if (line_intersect(start, end, box1, box2))
					return false;
				//UL-UR
				box1 = Vec2(y + .55f, x - .55f);
				box2 = Vec2(y + .55f, x + .55f);
				if (line_intersect(start, end, box1, box2))
					return false;
			}
		}
	}

	return true; // REPLACE THIS
}

void analyze_openness(MapLayer<float>& layer)
{
	/*
		Mark every cell in the given layer with the value 1 / (d * d),
		where d is the distance to the closest wall or edge.  Make use of the
		distance_to_closest_wall helper function.  Walls should not be marked.
	*/

	// WRITE YOUR CODE HERE
	int SizeX = terrain->get_map_width();
	int SizeY = terrain->get_map_height();

	for (int i = 0; i < SizeY; ++i)
	{
		for (int j = 0; j < SizeX; ++j)
		{
			if (terrain->is_valid_grid_position(i, j))
			{
				if (!terrain->is_wall(i, j))
				{
					float d = distance_to_closest_wall(i, j);
					float value = 1.f / (d * d);
					layer.set_value(i, j, value);
				}
			}
		}
	}
}

void analyze_visibility(MapLayer<float>& layer)
{
	/*
		Mark every cell in the given layer with the number of cells that
		are visible to it, divided by 160 (a magic number that looks good).  Make sure
		to cap the value at 1.0 as well.

		Two cells are visible to each other if a line between their centerpoints doesn't
		intersect the four boundary lines of every wall cell.  Make use of the is_clear_path
		helper function.
	*/
	const int width = terrain->get_map_width();
	const int height = terrain->get_map_height();

	//for each cell
	for (int row = 0; row < height; ++row)
	{
		for (int col = 0; col < width; ++col)
		{
			if (row == 0 && col == 4)
			{
				int a = 1;
			}
			
			//no need for wall
			//if (terrain->is_wall(row, col))
			//	continue;
			
			float counter = 0;
			//check with rest of the cells
			for (int y = 0; y < height; ++y)
			{
				for (int x = 0; x < width; ++x)
				{
					//no need to check itself
					if (row == y && col == x)
						continue;
					//no need to check wall
					//if (terrain->is_wall(y, x))
					//	continue;
					//if current pos is visible to this pos
					if (is_clear_path(row, col, y, x))
						counter++;
				}
			}
			
			counter /= 160.f;
			if (counter > 1.f)
				counter = 1.f;
			layer.set_value(row, col, counter);
		}
	}

	
	// WRITE YOUR CODE HERE
}

void analyze_visible_to_cell(MapLayer<float>& layer, int row, int col)
{
	/*
		For every cell in the given layer mark it with 1.0ss
		if it is visible to the given cell, 0.5 if it isn't visible but is next to a visible cell,
		or 0.0 otherwise.

		Two cells are visible to each other if a line between their centerpoints doesn't
		intersect the four boundary lines of every wall cell.  Make use of the is_clear_path
		helper function.
	*/
	int width = terrain->get_map_width();
	int height = terrain->get_map_height();

	for (int y = 0; y < height; ++y)
	{
		for (int x = 0; x < width; ++x)
		{
			if (terrain->is_wall(y, x))
				continue;
			if (y == 0 && x == 8)
				int a = 0;
			if (y == 2 && x == 1)
				int a = 0;

			
			if (is_clear_path(row, col, y, x))
			{
				layer.set_value(y, x, 1.f);
			}
			else if (is_clear_path(row, col, y - 1, x))
			{
				if (terrain->is_valid_grid_position(y - 1, x))
				{
					layer.set_value(y, x, 0.5f);
				}
			}
			else if (is_clear_path(row, col, y + 1, x))
			{
				if (terrain->is_valid_grid_position(y + 1, x))
				{
					layer.set_value(y, x, 0.5f);
				}
			}
			else if (is_clear_path(row, col, y, x - 1))
			{
				if (terrain->is_valid_grid_position(y, x - 1))
				{
					layer.set_value(y, x, 0.5f);
				}
			}
			else if (is_clear_path(row, col, y , x + 1))
			{
				if (terrain->is_valid_grid_position(y , x + 1))
				{
					layer.set_value(y, x, 0.5f);
				}
			}
			else
			{
				layer.set_value(y, x, 0.f);
			}
		}
	}
	// WRITE YOUR CODE HERE
}

void analyze_agent_vision(MapLayer<float>& layer, const Agent* agent)
{
	/*
		For every cell in the given layer that is visible to the given agent,
		mark it as 1.0, otherwise don't change the cell's current value.

		You must consider the direction the agent is facing.  All of the agent data is
		in three dimensions, but to simplify you should operate in two dimensions, the XZ plane.

		Take the dot product between the view vector and the vector from the agent to the cell,
		both normalized, and compare the cosines directly instead of taking the arccosine to
		avoid introducing floating-point inaccuracy (larger cosine means smaller angle).

		Give the agent a field of view slighter larger than 180 degrees.

		Two cells are visible to each other if a line between their centerpoints doesn't
		intersect the four boundary lines of every wall cell.  Make use of the is_clear_path
		helper function.
	*/
	// WRITE YOUR CODE HERE

	//Vec3 forwardVector = agent->get_forward_vector();//view vector

	//view vector = vector from agent to target node

	//if angle between is bigger than 90, 


	//agent facing
	Vec3 forwardVector = agent->get_forward_vector();
	//agent pos in world
	Vec3 agentWorldPos = agent->get_position();
	GridPos agentGridPos = terrain->get_grid_position(agentWorldPos);
	//for each cell
	int width = terrain->get_map_width();
	int height = terrain->get_map_height();

	float ninetyDegree = 3.14159f / 2.f;

	//	skipping walls
	for(int row =0; row<height; ++row)
	{
		for(int col =0; col<width; ++col)
		{
			//	is clear path? between curr index and agent location(grid pos)
			if (is_clear_path(row, col, agentGridPos.row, agentGridPos.col))
			{
				// get vector from agent to curr cell
				Vec3 cellWorldPos = terrain->get_world_position(row, col);
				Vec3 agentToCell = cellWorldPos - agentWorldPos;

				float dot = forwardVector.x * agentToCell.x + forwardVector.z * agentToCell.z;
				// normalize agent forward vect and new vector
				forwardVector.Normalize();
				agentToCell.Normalize();

				// then find angle
				//float angle = dot / (forwardVector.x * agentToCell.x + forwardVector.z * agentToCell.z);

				float angle = forwardVector.x * agentToCell.x + forwardVector.z * agentToCell.z;
				
				if(angle < ninetyDegree)
				{
					if(!terrain->is_wall(row,col))
						layer.set_value(row, col, 1.0);
				}
			}
		}
	}
	//	is clear path? between curr index and agent location(grid pos)
	//		get vector from agent to curr cell
	//		normalize agent forward vect and new vector
	//		then find angle
	//			if angle < 90 degrees or pi/2
	//				setvalue(pos, pos, Cell_visible) <- macros
	//				

	
}

void propagate_solo_occupancy(MapLayer<float>& layer, float decay, float growth)
{
	/*
		For every cell in the given layer:

			1) Get the value of each neighbor and apply decay factor
			2) Keep the highest value from step 1
			3) Linearly interpolate from the cell's current value to the value from step 2
			   with the growing factor as a coefficient.  Make use of the lerp helper function.
			4) Store the value from step 3 in a temporary layer.
			   A float[40][40] will suffice, no need to dynamically allocate or make a new MapLayer.

		After every cell has been processed into the temporary layer, write the temporary layer into
		the given layer;
	*/

	// WRITE YOUR CODE HERE
	int width = terrain->get_map_width();
	int height = terrain->get_map_height();

	//float decay = 0.2f;
	//float growth = 0.3f;

	int neighborX = 0;
	int neighborY = 0;

	float sq2 = sqrtf(2.f);

	float TempLayer[40][40] = { 0 };

	for (int y = 0; y < height; ++y)
	{

		for (int x = 0; x < width; ++x)
		{
			float neighborValue = 0.f;
			float maxValue = 0.f;
			if (terrain->is_wall(y, x))
				continue;
			//NW
			neighborX = x - 1;
			neighborY = y + 1;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					if(!terrain->is_wall(neighborY-1, neighborX) && !terrain->is_wall(neighborY, neighborX+1))
					{
						neighborValue = layer.get_value(neighborY, neighborX) * expf(-sq2 * decay);

						if (neighborValue > maxValue)
							maxValue = neighborValue;
						
					}
					
				}
			}
			//N
			neighborX = x;
			neighborY = y + 1;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					neighborValue = layer.get_value(neighborY, neighborX) * expf(-1.f * decay);

					if (neighborValue > maxValue)
						maxValue = neighborValue;
				}
			}
			//NE
			neighborX = x + 1;
			neighborY = y + 1;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					if (!terrain->is_wall(neighborY - 1, neighborX) && !terrain->is_wall(neighborY, neighborX - 1))
					{
						neighborValue = layer.get_value(neighborY, neighborX) * expf(-sq2 * decay);

						if (neighborValue > maxValue)
							maxValue = neighborValue;
					}
				}
			}
			//E
			neighborX = x + 1;
			neighborY = y;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					neighborValue = layer.get_value(neighborY, neighborX) * expf(-1.f * decay);

					if (neighborValue > maxValue)
						maxValue = neighborValue;
				}
			}
			//SE
			neighborX = x + 1;
			neighborY = y - 1;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					if (!terrain->is_wall(neighborY + 1, neighborX) && !terrain->is_wall(neighborY, neighborX - 1))
					{
						neighborValue = layer.get_value(neighborY, neighborX) * expf(-sq2 * decay);

						if (neighborValue > maxValue)
							maxValue = neighborValue;
					}
				}
			}
			//S
			neighborX = x;
			neighborY = y - 1;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					neighborValue = layer.get_value(neighborY, neighborX) * expf(-1.f * decay);

					if (neighborValue > maxValue)
						maxValue = neighborValue;
				}
			}
			//SW
			neighborX = x - 1;
			neighborY = y - 1;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					if (!terrain->is_wall(neighborY + 1, neighborX) && !terrain->is_wall(neighborY, neighborX + 1))
					{
						neighborValue = layer.get_value(neighborY, neighborX) * expf(-sq2 * decay);

						if (neighborValue > maxValue)
							maxValue = neighborValue;
					}
				}
			}
			//W
			neighborX = x - 1;
			neighborY = y;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					neighborValue = layer.get_value(neighborY, neighborX) * expf(-1.f * decay);
					if (neighborValue > 0)
					{
						int a = 0;
					}
					if (neighborValue > maxValue)
						maxValue = neighborValue;
				}
			}
			if (maxValue > 1.f)
				maxValue = 1.f;
			
			float value = lerp(layer.get_value(y, x), maxValue, growth);
			TempLayer[y][x] = value;
			//maxValue = 0;
		}
	}//END OF CHECKING NEIGHBOR LOOP

	for (int y = 0; y < height; ++y)
	{
		for (int x = 0; x < width; ++x)
		{
			if (!terrain->is_wall(y, x))
			{
				float newValue = TempLayer[y][x];
				layer.set_value(y, x, newValue);
			}
		}
	}

}

void propagate_dual_occupancy(MapLayer<float>& layer, float decay, float growth)
{
	/*
		Similar to the solo version, but the values range from -1.0 to 1.0, instead of 0.0 to 1.0

		For every cell in the given layer:

		1) Get the value of each neighbor and apply decay factor
		2) Keep the highest ABSOLUTE value from step 1
		3) Linearly interpolate from the cell's current value to the value from step 2
		   with the growing factor as a coefficient.  Make use of the lerp helper function.
		4) Store the value from step 3 in a temporary layer.
		   A float[40][40] will suffice, no need to dynamically allocate or make a new MapLayer.

		After every cell has been processed into the temporary layer, write the temporary layer into
		the given layer;
	*/

	// WRITE YOUR CODE HERE
	int width = terrain->get_map_width();
	int height = terrain->get_map_height();

	//float decay = 0.2f;
	//float growth = 0.3f;

	int neighborX = 0;
	int neighborY = 0;

	const float sq2 = sqrtf(2.f);

	float TempLayer[40][40] = { 0 };

	for (int y = 0; y < height; ++y)
	{

		for (int x = 0; x < width; ++x)
		{
			if (y == 19 && x == 0)
			{
				if (fabs(layer.get_value(19, 1)) > 0)
					int a = 0;
			}
			float neighborValue = 0.f;
			float maxValue = 0.f;
			if (terrain->is_wall(y, x))
				continue;
			//NW
			neighborX = x - 1;
			neighborY = y + 1;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					if (!terrain->is_wall(neighborY - 1, neighborX) && !terrain->is_wall(neighborY, neighborX + 1))
					{
						neighborValue = layer.get_value(neighborY, neighborX) * expf(-sq2 * decay);

						if (fabs(neighborValue) > fabs(maxValue))
							maxValue = neighborValue;
					}
				}
			}
			//N
			neighborX = x;
			neighborY = y + 1;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					neighborValue = layer.get_value(neighborY, neighborX) * expf(-1.f * decay);

					if (fabs(neighborValue) > fabs(maxValue))
						maxValue = neighborValue;
				}
			}
			//NE
			neighborX = x + 1;
			neighborY = y + 1;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					if (!terrain->is_wall(neighborY - 1, neighborX) && !terrain->is_wall(neighborY, neighborX - 1))
					{
						neighborValue = layer.get_value(neighborY, neighborX) * expf(-sq2 * decay);

						if (fabs(neighborValue) > fabs(maxValue))
							maxValue = neighborValue;
					}
				}
			}
			//E
			neighborX = x + 1;
			neighborY = y;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					neighborValue = layer.get_value(neighborY, neighborX) * expf(-1.f * decay);

					if (fabs(neighborValue) > fabs(maxValue))
						maxValue = neighborValue;
				}
			}
			//SE
			neighborX = x + 1;
			neighborY = y - 1;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					if (!terrain->is_wall(neighborY + 1, neighborX) && !terrain->is_wall(neighborY, neighborX - 1))
					{
						neighborValue = layer.get_value(neighborY, neighborX) * expf(-sq2 * decay);

						if (fabs(neighborValue) > fabs(maxValue))
							maxValue = neighborValue;
					}
				}
			}
			//S
			neighborX = x;
			neighborY = y - 1;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					neighborValue = layer.get_value(neighborY, neighborX) * expf(-1.f * decay);

					if (fabs(neighborValue) > fabs(maxValue))
						maxValue = neighborValue;
				}
			}
			//SW
			neighborX = x - 1;
			neighborY = y - 1;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					if (!terrain->is_wall(neighborY + 1, neighborX) && !terrain->is_wall(neighborY, neighborX + 1))
					{
						neighborValue = layer.get_value(neighborY, neighborX) * expf(-sq2 * decay);

						if (fabs(neighborValue) > fabs(maxValue))
							maxValue = neighborValue;
					}
				}
			}
			//W
			neighborX = x - 1;
			neighborY = y;
			if (terrain->is_valid_grid_position(neighborY, neighborX))
			{
				if (!terrain->is_wall(neighborY, neighborX))
				{
					neighborValue = layer.get_value(neighborY, neighborX) * expf(-1.f * decay);
					if (neighborValue > 0)
					{
						int a = 0;
					}
					if (fabs(neighborValue) > fabs(maxValue))
						maxValue = neighborValue;
				}
			}

			float value = lerp(layer.get_value(y, x), maxValue, growth);
			TempLayer[y][x] = value;
			//maxValue = 0;
		}
	}//END OF CHECKING NEIGHBOR LOOP

	for (int y = 0; y < height; ++y)
	{
		for (int x = 0; x < width; ++x)
		{
			if (!terrain->is_wall(y, x))
			{
				float newValue = TempLayer[y][x];
				layer.set_value(y, x, newValue);
			}
		}
	}

}

void normalize_solo_occupancy(MapLayer<float>& layer)
{
	/*
		Determine the maximum value in the given layer, and then divide the value
		for every cell in the layer by that amount.  This will keep the values in the
		range of [0, 1].  Negative values should be left unmodified.
	*/



	// WRITE YOUR CODE HERE
	const int width = terrain->get_map_width();
	const int height = terrain->get_map_height();

	float maxValue = 0;
	
	for(int y=0; y<height; ++y)
	{
		for(int x=0; x<width; ++x)
		{
			float currValue = 0.f;
			currValue = (layer.get_value(y, x));
			
			if (currValue < 0)
				continue;

			if (currValue > maxValue)
			{
				maxValue = layer.get_value(y, x);
			}
		}
	}

	if (maxValue==0)
		return;
	for (int y = 0; y < height; ++y)
	{
		for (int x = 0; x < width; ++x)
		{

				float oldValue = layer.get_value(y, x);
				if (oldValue == 0.f)
					oldValue = 0.001f;

				float newValue = oldValue / maxValue;
				if (newValue > 1.f)
					newValue = 1.f;
				layer.set_value(y, x, newValue);
			
			
		}
	}
	
}

void normalize_dual_occupancy(MapLayer<float>& layer)
{
	/*
		Similar to the solo version, but you need to track greatest positive value AND
		the least (furthest from 0) negative value.

		For every cell in the given layer, if the value is currently positive divide it by the
		greatest positive value, or if the value is negative divide it by -1.0 * the least negative value
		(so that it remains a negative number).  This will keep the values in the range of [-1, 1].
	*/

	// WRITE YOUR CODE HERE

	const int width = terrain->get_map_width();
	const int height = terrain->get_map_height();

	float maxValue = 0.f;
	float minValue = 0.f;

	for (int y = 0; y < height; ++y)
	{
		for (int x = 0; x < width; ++x)
		{
			float currValue = (layer.get_value(y, x));
			if (currValue > maxValue)
				maxValue = currValue;
			if (currValue < minValue)
				minValue = currValue;
		}
	}
	if (maxValue == 0.f)
		return;
	if (minValue == 0.f)
		return;
	for (int row = 0; row < height; ++row)
	{
		for (int col = 0; col < width; ++col)
		{
			float oldValue = layer.get_value(row, col);
			if(oldValue >= 0)
			{
				if (oldValue == 0.f)
					oldValue = 0.001f;
				
				float newValue = oldValue / maxValue;
				if (newValue > 1.f)
					newValue = 1.f;
				layer.set_value(row, col, newValue);
			}
			else
			{
				float newValue = oldValue / (minValue*-1.f);
				if (newValue < -1.f)
					newValue = -1.f;
				layer.set_value(row, col, newValue);
			}
		}
	}
}

float CalculateDistance(int row0, int col0, int row1, int col1)
{
	return sqrtf(static_cast<float>((col1 - col0) * (col1 - col0) + (row1 - row0) * (row1 - row0)));
}

void enemy_field_of_view(MapLayer<float>& layer, float fovAngle, float closeDistance, float occupancyValue, AStarAgent* enemy)
{
	/*
		First, clear out the old values in the map layer by setting any negative value to 0.
		Then, for every cell in the layer that is within the field of view cone, from the
		enemy agent, mark it with the occupancy value.  Take the dot product between the view
		vector and the vector from the agent to the cell, both normalized, and compare the
		cosines directly instead of taking the arccosine to avoid introducing floating-point
		inaccuracy (larger cosine means smaller angle).

		If the tile is close enough to the enemy (less than closeDistance),
		you only check if it's visible to enemy.  Make use of the is_clear_path
		helper function.  Otherwise, you must consider the direction the enemy is facing too.
		This creates a radius around the enemy that the player can be detected within, as well
		as a fov cone.
	*/

	// WRITE YOUR CODE HERE
	

	const int width = terrain->get_map_width();
	const int height = terrain->get_map_height();

	//agent facing
	Vec3 forwardVector = enemy->get_forward_vector();
	//agent pos in world
	Vec3 agentWorldPos = enemy->get_position();
	GridPos agentGridPos = terrain->get_grid_position(agentWorldPos);
	//for each cell

	for (int row = 0; row < height; ++row)
	{
		for (int col = 0; col < width; ++col)
		{
			//Clear out any negative value
			if (layer.get_value(row, col) < 0)
				layer.set_value(row, col, 0.f);
		}
	}

	
	//	skipping walls
	for (int row = 0; row < height; ++row)
	{
		for (int col = 0; col < width; ++col)
		{
			
			//	is clear path? between curr index and agent location(grid pos)
			if (is_clear_path(row, col, agentGridPos.row, agentGridPos.col))
			{
				// get vector from agent to curr cell
				Vec3 cellWorldPos = terrain->get_world_position(row, col);
				Vec3 agentToCell = cellWorldPos - agentWorldPos;

				float dot = forwardVector.x * agentToCell.x + forwardVector.z * agentToCell.z;
				//// normalize agent forward vect and new vector
				forwardVector.Normalize();
				agentToCell.Normalize();
				//
				//// then find angle
				float angle = dot / (forwardVector.x * agentToCell.x + forwardVector.z * agentToCell.z);

				//float angle = (forwardVector.x * agentToCell.x + forwardVector.z * agentToCell.z);
				//angle = acos(angle) * 180.f / 3.14f;
				

				if (angle < fovAngle)
				{
					layer.set_value(row, col, occupancyValue);
				}
			}


			if (closeDistance > CalculateDistance(row, col, agentGridPos.row, agentGridPos.col))
			{
				if (is_clear_path(row, col, agentGridPos.row, agentGridPos.col))
				{
					layer.set_value(row, col, occupancyValue);
				}
			}
		}
	}

	
}

bool enemy_find_player(MapLayer<float>& layer, AStarAgent* enemy, Agent* player)
{
	/*
		Check if the player's current tile has a negative value, ie in the fov cone
		or within a detection radius.
	*/

	const auto& playerWorldPos = player->get_position();
	const auto playerGridPos = terrain->get_grid_position(playerWorldPos);

	

	// verify a valid position was returned
	if (terrain->is_valid_grid_position(playerGridPos) == true)
	{
		if (layer.get_value(playerGridPos) < 0.0f)
		{
			return true;
		}
	}

	// player isn't in the detection radius or fov cone, OR somehow off the map
	return false;
}



bool enemy_seek_player(MapLayer<float>& layer, AStarAgent* enemy)
{
	/*
		Attempt to find a cell with the highest nonzero value (normalization may
		not produce exactly 1.0 due to floating point error), and then set it as
		the new target, using enemy->path_to.

		If there are multiple cells with the same highest value, then pick the
		cell closest to the enemy.

		Return whether a target cell was found.
	*/

	const int width = terrain->get_map_width();
	const int height = terrain->get_map_height();

	float highestValue = -1000.f;//magic number
	GridPos destination={0};

	const GridPos enemyPos = terrain->get_grid_position(enemy->get_position());
	
	for (int row = 0; row < height; ++row)
	{
		for (int col = 0; col < width; ++col)
		{
			if (layer.get_value(row, col) > highestValue)
			{
				highestValue = layer.get_value(row, col);
				destination.row = row;
				destination.col = col;
			}
			else if (layer.get_value(row, col) == highestValue)
			{
				float distance0 = CalculateDistance(destination.row, destination.col,enemyPos.row, enemyPos.col);
				float distance1 = CalculateDistance(row, col,enemyPos.row, enemyPos.col);
				if (distance1 < distance0)
				{
					destination.row = row;
					destination.col = col;
				}
			}
		}
	}

	Vec3 distanceWorldPos = terrain->get_world_position(destination);
	
	//enemy->path_to(distanceWorldPos, )

		// WRITE YOUR CODE HERE
	if (highestValue == 0)
		return false; // REPLACE THIS
	else
	{
		enemy->path_to(distanceWorldPos, true);
		return true;
	}
}
