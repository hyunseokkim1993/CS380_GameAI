#pragma once
#include "Misc/PathfindingDetails.hpp"

struct Node
{
    GridPos pos;
    float cost = 0;
    float g = 0;
    int parentx;
    int parenty;
};


class AStarPather
{
public:

	
    /* 
        The class should be default constructible, so you may need to define a constructor.
        If needed, you can modify the framework where the class is constructed in the
        initialize functions of ProjectTwo and ProjectThree.
    */
    int width;
	int height;
	
    std::vector<Node>openlist;
    std::vector<Node>closedlist;
    std::vector<Node>NodePath;
    std::vector<std::vector<bool>> visited;// (int height, std::vector<bool>(int width, bool b));
	
    /* ************************************************** */
    // DO NOT MODIFY THESE SIGNATURES
    bool initialize();
    void shutdown();
    PathResult compute_path(PathRequest &request);
    /* ************************************************** */

    /*
        You should create whatever functions, variables, or classes you need.
        It doesn't all need to be in this header and cpp, structure it whatever way
        makes sense to you.
    */

};