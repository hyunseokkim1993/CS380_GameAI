#include <pch.h>
#include "Projects/ProjectTwo.h"
#include "P2_Pathfinding.h"

#include "SimpleMath.h"

#pragma region Extra Credit
bool ProjectTwo::implemented_floyd_warshall()
{
	return false;
}

bool ProjectTwo::implemented_goal_bounding()
{
	return false;
}

bool ProjectTwo::implemented_jps_plus()
{
	return false;
}
#pragma endregion

bool AStarPather::initialize()
{
	// handle any one-time setup requirements you have

	/*
		If you want to do any map-preprocessing, you'll need to listen
		for the map change message.  It'll look something like this:

		Callback cb = std::bind(&AStarPather::your_function_name, this);
		Messenger::listen_for_message(Messages::MAP_CHANGE, cb);

		There are other alternatives to using std::bind, so feel free to mix it up.
		Callback is just a typedef for std::function<void(void)>, so any std::invoke'able
		object that std::function can wrap will suffice.
	*/

	//auto cb = std::bind(&AStarPather::initialize, this);
	//Messenger::listen_for_message(Messages::MAP_CHANGE, cb);

	//std::vector<std::vector<bool>>map;

	//int height = terrain->get_map_height();
	//int width = terrain->get_map_width();

	//for(int i =0; i<height; ++i)
	//{
	//	for(int j =0; i<width; ++j)
	//	{
	//		map[i][j] = terrain->is_wall(i,j);
	//	}
	//}

	return true; // return false if any errors actually occur, to stop engine initialization
}

void AStarPather::shutdown()
{
	/*
		Free any dynamically allocated memory or any other general house-
		keeping you need to do during shutdown.
	*/
}

//struct Node
//{
//	GridPos pos;
//	float cost = 0;
//	float g = 0;
//	int parentx;
//	int parenty;
//};

bool CompareCost(Node n1, Node n2)
{
	if (n1.cost == n2.cost)
		return n1.g > n2.g;
	return (n1.cost < n2.cost);
}

float CalculateHeuristic(Heuristic type, GridPos curr, GridPos goal)
{
	int x = abs(goal.col - curr.col);
	int y = abs(goal.row - curr.row);

	if (type == Heuristic::OCTILE)
	{
		return std::min(x, y) * 1.41f + std::max(x, y) - std::min(x, y);
		//return 1.41f * std::min(x, y) + (float)abs(x - y);
	}
	else if (type == Heuristic::CHEBYSHEV)
	{
		return static_cast<float>(std::max(x, y));
	}
	else if (type == Heuristic::MANHATTAN)
	{
		return static_cast<float>(x + y);
	}
	else if (type == Heuristic::EUCLIDEAN)
	{
		return static_cast<float>(sqrt(x * x + y * y));
	}
	else
	{
		return 0;
	}
}

float CalculateDistance(GridPos curr, GridPos old)
{
	int x = abs(curr.col - old.col);
	int y = abs(curr.row - old.row);

	if (x == 0 || y == 0)
	{
		return 1.f;//adjacent
	}
	else
	{
		return 1.41f;//diagonal
	}
}

//Search the rectangle built by three nodes
bool CanRubberband(Node anchor, Node n1, Node n2)
{
	int minX = std::min(anchor.pos.col, std::min(n1.pos.col, n2.pos.col));
	int maxX = std::max(anchor.pos.col, std::max(n1.pos.col, n2.pos.col));
	int minY = std::min(anchor.pos.row, std::min(n1.pos.row, n2.pos.row));
	int maxY = std::max(anchor.pos.row, std::max(n1.pos.row, n2.pos.row));

	for (int i = minY; i <= maxY; ++i)
	{
		for (int j = minX; j <= maxX; ++j)
		{
			if (terrain->is_valid_grid_position(i, j))
			{
				if (terrain->is_wall(i, j))
				{
					return false;
				}
			}
		}
	}
	return true;
}

bool AreNodesFarEnough(Vec3 a, Vec3 b)
{
	if (3.f < sqrt((a.x - b.x) * (a.x - b.x) + (a.z - b.z) * (a.z - b.z)))
		return true;
	return false;
}



PathResult AStarPather::compute_path(PathRequest& request)
{
	/*
		This is where you handle pathing requests, each request has several fields:

		start/goal - start and goal world positions
		path - where you will build the path upon completion, path should be
			start to goal, not goal to start
		heuristic - which heuristic calculation to use
		weight - the heuristic weight to be applied
		newRequest - whether this is the first request for this path, should generally
			be true, unless single step is on

		smoothing - whether to apply smoothing to the path
		rubberBanding - whether to apply rubber banding
		singleStep - whether to perform only a single A* step
		debugColoring - whether to color the grid based on the A* state:
			closed list nodes - yellow
			open list nodes - blue

			use terrain->set_color(row, col, Colors::YourColor);
			also it can be helpful to temporarily use other colors for specific states
			when you are testing your algorithms

		method - which algorithm to use: A*, Floyd-Warshall, JPS+, or goal bounding,
			will be A* generally, unless you implement extra credit features

		The return values are:
			PROCESSING - a path hasn't been found yet, should only be returned in
				single step mode until a path is found
			COMPLETE - a path to the goal was found and has been built in request.path
			IMPOSSIBLE - a path from start to goal does not exist, do not add start position to path
	*/

	// WRITE YOUR CODE HERE
	
	//Map data
	int height = terrain->get_map_height();
	int width = terrain->get_map_width();


	//Initialize
	const GridPos start = terrain->get_grid_position(request.start);
	const GridPos goal = terrain->get_grid_position(request.goal);

	Heuristic type = request.settings.heuristic;
	
	if (request.newRequest)
	{
		openlist.clear();
		closedlist.clear();
		NodePath.clear();
		visited.clear();

		//Checklist for visited nodes
		visited = std::vector<std::vector<bool>>(height, std::vector<bool>(width, false));

		const float startCost = CalculateHeuristic(type, start, goal);
		const Node startNode{ start, startCost, 0, -1, -1 };
		visited[start.row][start.col] = true;

		openlist.push_back(startNode);
	}

	//std::vector<Node>openlist;
	//std::vector<Node>closedlist;



	//request.settings.singleStep = true;

	while (!openlist.empty())
	{
		//Pop cheapest node off openlist + Assign parent node
		std::sort(openlist.begin(), openlist.end(), CompareCost);
		Node parentNode = openlist.at(0);
		openlist.erase(openlist.begin());

		//Found Goal
		if (parentNode.pos == goal)
		{
			closedlist.push_back(parentNode);
			break;
		}

		for (int i = -1; i <= 1; ++i)
		{
			for (int j = -1; j <= 1; ++j)
			{
				//No need to check parent node
				if (j == 0 && i == 0) { continue; }

				//Initialize current position
				const GridPos currPos{ parentNode.pos.row + i, parentNode.pos.col + j };

				//Check if current position is valid or walkable
				if (!terrain->is_valid_grid_position(currPos) || terrain->is_wall(currPos))
				{
					continue;
				}
				if (currPos == start)
				{
					continue;
				}

				//If moving diagonal, check cutting-corners
				if (j == 1 && i == 1)//Moving NE, check left-down
				{
					if (terrain->is_valid_grid_position(currPos.row - 1, currPos.col) && terrain->is_valid_grid_position(currPos.row, currPos.col - 1))
					{
						if (terrain->is_wall(currPos.row - 1, currPos.col) || terrain->is_wall(currPos.row, currPos.col - 1))
						{
							continue;
						}
					}
				}
				if (j == 1 && i == -1)//Moving SE, check left-up
				{
					if (terrain->is_valid_grid_position(currPos.row + 1, currPos.col) && terrain->is_valid_grid_position(currPos.row, currPos.col - 1))
					{
						if (terrain->is_wall(currPos.row + 1, currPos.col) || terrain->is_wall(currPos.row, currPos.col - 1))
						{
							continue;
						}
					}
				}
				if (j == -1 && i == -1)//Moving SW, check right-up
				{
					if (terrain->is_valid_grid_position(currPos.row + 1, currPos.col) && terrain->is_valid_grid_position(currPos.row, currPos.col + 1))
					{
						if (terrain->is_wall(currPos.row + 1, currPos.col) || terrain->is_wall(currPos.row, currPos.col + 1))
						{
							continue;
						}
					}
				}
				if (j == -1 && i == 1)//Moving NW, check right-down
				{
					if (terrain->is_valid_grid_position(currPos.row - 1, currPos.col) && terrain->is_valid_grid_position(currPos.row, currPos.col + 1))
					{
						if (terrain->is_wall(currPos.row - 1, currPos.col) || terrain->is_wall(currPos.row, currPos.col + 1))
						{
							continue;
						}
					}
				}

				//Calculate Cost
				float g = CalculateDistance(currPos, parentNode.pos) + parentNode.g;
				float h = CalculateHeuristic(type, currPos, goal) * request.settings.weight;

				const float cost = g + h;
				const Node currNode{ currPos, cost, g, parentNode.pos.col, parentNode.pos.row };

				//If this node has never been visited, put it on openlist
				if (!visited[currPos.row][currPos.col])
				{
					visited[currPos.row][currPos.col] = true;
					openlist.push_back(currNode);
					terrain->set_color(currPos, Colors::Blue);
				}

				//If node has been visited
				else
				{
					//Check if node is on open list
					for (std::vector<Node>::iterator it = openlist.begin(); it != openlist.end(); ++it)
					{
						if (currPos == it->pos)
						{
							//if new node is cheaper
							if (cost < it->cost)
							{
								//erase existing node and put cheaper node on open list
								openlist.erase(it);
								openlist.push_back(currNode);
								terrain->set_color(currPos, Colors::Blue);
								//return::PathResult::PROCESSING;
								break;
							}
						}
					}
					//Check if node is on closed list
					for (std::vector<Node>::iterator it = closedlist.begin(); it != closedlist.end(); ++it)
					{
						if (currPos == it->pos)
						{
							//if new node is cheaper
							if (cost < it->cost)
							{
								//erase existing node and put cheaper node on closed list
								closedlist.erase(it);
								openlist.push_back(currNode);
								terrain->set_color(currPos, Colors::Blue);
								//return::PathResult::PROCESSING;
								break;
							}
						}
					}
				}
			}
		}//END OF CHECKING NEIGHBOR LOOP
		closedlist.push_back(parentNode);
		terrain->set_color(parentNode.pos, Colors::Yellow);

		if (openlist.empty())
		{
			return PathResult::IMPOSSIBLE;
		}
		
		if(request.settings.singleStep)
			return::PathResult::PROCESSING;
	}//END OF WHILE LOOP

	//Find the node that arrived at goal..Dirty code change later
	int pathx = goal.col;
	int pathy = goal.row;
	Node endNode;
	for (std::vector<Node>::reverse_iterator it = closedlist.rbegin(); it != closedlist.rend(); ++it)
	{
		if (it->pos.col == pathx && it->pos.row == pathy)
		{
			endNode = *it;
			pathx = it->parentx;
			pathy = it->parenty;
			break;
		}
	}

	//Build Path
	//std::vector<Node>NodePath;
	NodePath.push_back(endNode);
	for (std::vector<Node>::reverse_iterator it = closedlist.rbegin(); it != closedlist.rend(); ++it)
	{
		if (it->pos.col == pathx && it->pos.row == pathy)
		{
			NodePath.push_back(*it);
			pathy = it->parenty;
			pathx = it->parentx;
		}
	}
	
	//Rebuilding path using rubber band
	if (request.settings.rubberBanding)
	{
		size_t size = NodePath.size() - 1;
		Node anchor = NodePath.back();		//This is the 'endpoint' during the check
		Node n1;							//Node 1 step away from anchor
		Node n2;							//Node 2 step away from anchor
		size_t index1 = size - 1;			//Index for n1
		size_t index2 = size - 2;			//Index for n2

		bool shouldRubberband = true;

		while (shouldRubberband)
		{
			if (index2 == 0)//Beyond this point would be out of bound
			{
				shouldRubberband = false;
				break;
			}

			n1 = NodePath.at(index1);
			n2 = NodePath.at(index2);

			//If there is no obstacle between 3 nodes
			if (CanRubberband(anchor, n1, n2))
			{
				//erase middle node
				NodePath.erase(NodePath.begin() + index1);
				--index1;
				--index2;
				n1 = NodePath.at(index1);
				n2 = NodePath.at(index2);
			}
			//else move anchor
			else
			{
				if (index2 > 0)
				{
					anchor = n1;
					--index1;
					--index2;
					n1 = NodePath.at(index1);
					n2 = NodePath.at(index2);
				}
			}
		}
	}



	
	//Push Final path on world coordinate
	Vec3 worldPos;
	if(NodePath.size() > 1)
	{
		for (std::vector<Node>::reverse_iterator it = NodePath.rbegin(); it != NodePath.rend(); ++it)
		{
			worldPos = terrain->get_world_position(it->pos.row, it->pos.col);
			request.path.push_back(worldPos);
		}
	}

	//Rebuilding path using BOTH rubber band & smoothing
	if (request.settings.smoothing && request.settings.rubberBanding)
	{
		std::list<Vec3>::iterator it = request.path.begin();
		
		Vec3 first;
		Vec3 second;
		bool canEscape = false;

		size_t i = 0;

		while (!canEscape)
		{
			first = *it;
			advance(it, 1);
			second = *it;

			if(second == request.path.back())
			{
				break;
			}
			if (AreNodesFarEnough(first, second))
			{
				Vec3 newPos{ (first.x + second.x) / 2, 0, (first.z + second.z) / 2 };
				request.path.insert(it, newPos);
				advance(it, -2);
				continue;
			}
			else
			{
				advance(it, 1);
			}
		}
	}

	//Rebuilding path using smoothing
	if (request.settings.smoothing)
	{
		bool isFirst = true;
		size_t size = request.path.size() - 1;
		Vec3 p1 = request.path.front();		//This is the 'endpoint' during the check
		Vec3 p2;							//Node 1 step away from anchor
		Vec3 p3;							//Node 2 step away from anchor
		Vec3 p4;							//Node 3 step away from anchor
		size_t index1 = 1;			//Index for n1
		size_t index2 = 2;			//Index for n2
		size_t index3 = 3;			//Index for n3

		Vec3 new1;
		Vec3 new2;
		Vec3 new3;
		
		bool shouldSmooth = true;
		std::list<Vec3>::iterator it = request.path.begin();

		while (shouldSmooth)
		{
			if (isFirst)
			{
				std::list<Vec3>::iterator pos = request.path.begin();
				std::advance(pos, index1);
				p2 = *pos;
				std::advance(pos, 1);
				p3 = *pos;
				
				new1 = DirectX::SimpleMath::Vector3::CatmullRom(p1, p1, p2, p3, 0.25f);
				new2 = DirectX::SimpleMath::Vector3::CatmullRom(p1, p1, p2, p3, 0.5f);
				new3 = DirectX::SimpleMath::Vector3::CatmullRom(p1, p1, p2, p3, 0.75f);

				advance(it, 1);
				request.path.insert(it, new1);
				request.path.insert(it, new2);
				request.path.insert(it, new3);
				advance(it, -4);

				isFirst = false;
				continue;
			}
			
			///initialize
			p1 = *it;
			advance(it, 4);
			p2 = *it;
			advance(it, 1);
			p3 = *it;
			advance(it, 1);
			p4 = *it;
			
			//If last node
			if(p4 == request.path.back())
			{
				new1 = DirectX::SimpleMath::Vector3::CatmullRom(p1, p2, p3, p4, 0.25f);
				new2 = DirectX::SimpleMath::Vector3::CatmullRom(p1, p2, p3, p4, 0.5f);
				new3 = DirectX::SimpleMath::Vector3::CatmullRom(p1, p2, p3, p4, 0.75f);

				advance(it, -1);
				request.path.insert(it, new1);
				request.path.insert(it, new2);
				request.path.insert(it, new3);
				advance(it, -4);

				p1 = *it;
				advance(it, 4);
				p2 = *it;
				advance(it, 1);
				p3 = *it;
				//advance(it, 1);
				//p4 = *it;

				new1 = DirectX::SimpleMath::Vector3::CatmullRom(p1, p2, p3, p3, 0.25f);
				new2 = DirectX::SimpleMath::Vector3::CatmullRom(p1, p2, p3, p3, 0.5f);
				new3 = DirectX::SimpleMath::Vector3::CatmullRom(p1, p2, p3, p3, 0.75f);

				//advance(it, -2);
				request.path.insert(it, new1);
				request.path.insert(it, new2);
				request.path.insert(it, new3);
				advance(it, -4);
				
				break;
			}

			//else			
			new1 = DirectX::SimpleMath::Vector3::CatmullRom(p1, p2, p3, p4, 0.25f);
			new2 = DirectX::SimpleMath::Vector3::CatmullRom(p1, p2, p3, p4, 0.5f);
			new3 = DirectX::SimpleMath::Vector3::CatmullRom(p1, p2, p3, p4, 0.75f);

			advance(it, -1);
			request.path.insert(it, new1);
			request.path.insert(it, new2);
			request.path.insert(it, new3);
			advance(it, -4);
		}
	}
	
	//Debug print
	terrain->set_color(start, Colors::Orange);
	terrain->set_color(goal, Colors::Orange);

	//If parent node is (-1,-1) then it means that path arrived at start
	if (pathy == -1 && pathx == -1)
	{
		//request.path.push_back(request.goal);
		return PathResult::COMPLETE;
	}

	/*if (openlist.empty())
	{
		return PathResult::IMPOSSIBLE;
	}*/

	return PathResult::IMPOSSIBLE;
}
