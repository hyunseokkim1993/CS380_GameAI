Student Name: Kevin Kim

Special Directions (if any): Please run the program in release mode

Missing features (if any):

My experience working on this project: I wish instruction for each function was more clear.

Hours spent: 6-9

Extra credits: